﻿using System.Text;
using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NovaTela
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void Button_Click(object sender, RoutedEventArgs e)
        {
            // Nome
            if (Textbox_Nome.Text == "")
            {
                MessageBox.Show("Por favor, insira um nome para o produto.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Código
            if (Textbox_Codigo.Text == "")
            {
                MessageBox.Show("Por favor, insira um código para o produto.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Senha
            if (Textbox_Preco.Text == "")
            {
                MessageBox.Show("Por favor, insira um preço para o produto.", "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            // CASO CORRETO

            if (Textbox_Nome.Text != "" && Textbox_Codigo.Text != "" && Textbox_Preco.Text != "")
            {
                string nome = Textbox_Nome.Text;
                string codigo = Textbox_Codigo.Text;
                string preco = Textbox_Preco.Text;

           
            }
        }

        private void Textbox_Nome_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void DataGrid_Main_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string nome = Textbox_Nome.Text;
            string codigo = Textbox_Codigo.Text;
            string preco = Textbox_Preco.Text;
            var rowData = DataGrid_Main.SelectedItem as DataGridMainClass;
        }
    }
}